branch_data<-read.table("C:/Users/nalin/Downloads/Lab 04-20250818/Exercise.txt",header=TRUE,sep=",")
str(branch_data)
sapply(branch_data,class)
boxplot(branch_data$Sales_X1,main="Box plot for Sales", outline=TRUE, outpch=8, horizontal= TRUE)
summary(branch_data$Branch)
summary(branch_data$Sales_X1)
summary(branch_data$advertising_X2)
summary(branch_data$Years_X3)
IQR(branch_data$Branch)
IQR(branch_data$Sales_X1)
IQR(branch_data$advertising_X2)
IQR(branch_data$Years_X3)
get.outliers<-function(z){
  q1<-quantile(z)[2]
  q3<-quantile(z)[4]
  iqr<- q3-q1
  
  ub <-q3+1.5*iqr
  lb <-q1-1.5*iqr
  
  print(paste("Upper bound = ",ub))
  print(paste("Lower bound = ",lb))
  print(paste("Outliners = ",paste(sort(z[z<lb | z>ub]),collapes=",")))
}
get.outliers(branch_data$Branch)
get.outliers(branch_data$Sales_X1)
get.outliers(branch_data$advertising_X2)
get.outliers(branch_data$Years_X3)

